package Fourth;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.WebDriver;
import utils.AutomationConstants;
import utils.BrowserFactory;

/**
 * Created by theop on 29/10/2017.
 */
public class Hooks {
    static WebDriver driver;

    @Before
    public static void start() {
        try {
            BrowserFactory.startBrowser(AutomationConstants.BROWSER_TYPE, AutomationConstants.URL);
            driver = BrowserFactory.getDriver(driver);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @After
    public static void closeBrowser() {
        BrowserFactory.stopBrowser();
    }


}
