package Fourth;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

/**
 * Created by theop on 29/10/2017.
 */
public class MyStepdefs {

    private HomePage homePage = new HomePage();
    private BooksPage booksPage = new BooksPage();
    private BookDetailsPage bookDetailsPage = new BookDetailsPage();
    private ShoppingBasketPage shoppingBasketPage = new ShoppingBasketPage();
    private EditShoppingBasketPage editShoppingBasketPage = new EditShoppingBasketPage();

    @Given("^User is in Amazon Home page$")
    public void userIsInAmazonHomePage() {
        String pageTitle = homePage.getHomePageTitle();
        String amazonPageText = homePage.inAmazonPage();
        Assert.assertTrue(pageTitle.contains("Amazon.co.uk"));
        Assert.assertTrue(amazonPageText.contains("Amazon.co.uk"));
    }

    @And("^Navigates to \"([^\"]*)\" department$")
    public void navigatesToDepartment(String booksSection) {
        homePage.gotoBooksSection(booksSection);
    }

    @When("^User searches for \"([^\"]*)\"$")
    public void userSearchesFor(String bookTitle) {
        homePage.searchsForABook(bookTitle);
    }

    @Then("^First book in results is \"([^\"]*)\"$")
    public void firstBookInResultsIs(String bookTitle) {
        String firstBookReturned = booksPage.bookTitle();
        Assert.assertEquals(bookTitle, firstBookReturned);
    }

    @And("^Book type selected is \"([^\"]*)\"$")
    public void bookTypeSelectedIs(String paperBackType) {
        String paperBackBookType = booksPage.bookType();
        Assert.assertEquals(paperBackType, paperBackBookType);
    }

    @And("^Book Cost is \"([^\"]*)\" and \"([^\"]*)\"$")
    public void bookCostIsAnd(String pounds, String pences) {
        String bookCostDisplayed = booksPage.bookPrice().replaceAll("[\\s.]", "");
        Assert.assertTrue(bookCostDisplayed.startsWith(pounds));
        Assert.assertTrue(bookCostDisplayed.endsWith(pences));
        Assert.assertEquals(bookCostDisplayed.length(), (pounds + pences).length());
    }

    @When("^User navigates to Book details$")
    public void userNavigatesToBookDetails() {
        booksPage.bookDetails();
    }

    @Then("^Book title in Book details page is \"([^\"]*)\"$")
    public void bookTitleInBookDetailsPageIs(String title) {
        String bookTitleDisplayed = bookDetailsPage.bookTitle();
        Assert.assertEquals(title, bookTitleDisplayed);
    }

    @And("^Book Price selected in Book details page is \"([^\"]*)\"$")
    public void bookPriceSelectedInBookDetailsPageIs(String price) throws InterruptedException {
        String bookPriceDisplayed = bookDetailsPage.bookPriceSelected();
        Assert.assertEquals(price, bookPriceDisplayed);
    }

    @And("^Book Type in Book details page is \"([^\"]*)\"$")
    public void bookTypeInBookDetailsPageIs(String type) {
        String bookTypeDisplayed = bookDetailsPage.bookTypeSelected();
        Assert.assertEquals(type, bookTypeDisplayed);
    }

    @When("^User adds to the Basket$")
    public void userAddsToTheBasket() throws Throwable {
        bookDetailsPage.addToBasket();
    }

    @Then("^\"([^\"]*)\" notification  is displayed$")
    public void notificationIsDisplayed(String notification) {
        String notificationDisplayed = shoppingBasketPage.addedToBasketNotification();
        Assert.assertEquals(notification, notificationDisplayed);
    }

    @And("^Number of items  displayed is \"([^\"]*)\"$")
    public void numberOfItemsDisplayedIs(String count) {
        String numberOfItems = shoppingBasketPage.numberOfItemsInBasket();
        Assert.assertTrue(numberOfItems.contains(count));
    }

    @When("^User edits The Basket$")
    public void userEditsTheBasket() {
        shoppingBasketPage.editBasket();
    }

    @Then("^User is navigated to \"([^\"]*)\" Page$")
    public void userIsNavigatedToPage(String shoppingBasket) {
        String shoppingBasketHeading = editShoppingBasketPage.inEditShoppingCartPage();
        Assert.assertEquals(shoppingBasket, shoppingBasketHeading);
    }

    @And("^Book title in Shopping Basket page  is \"([^\"]*)\"$")
    public void bookTitleInShoppingBasketPageIs(String bookTitle) {
        String bookTitleDisplayed = editShoppingBasketPage.bookTitleInshoppingBasketPage();
        Assert.assertEquals(bookTitle, bookTitleDisplayed);
    }

    @And("^Book Type in Shopping Basket page  is \"([^\"]*)\"$")
    public void bookTypeInShoppingBasketPageIs(String bookType) {
        String bookTypeDisplayed = editShoppingBasketPage.bookTypeinShoppingBasketpage();
        Assert.assertEquals(bookType, bookTypeDisplayed);
    }

    @And("^Book Price in Shopping Basket page  is \"([^\"]*)\"$")
    public void bookPriceInShoppingBasketPageIs(String bookPrice) {
        String bookPriceDisplayed = editShoppingBasketPage.bookPriceInShoppingBasketPage();
        Assert.assertEquals(bookPrice, bookPriceDisplayed);
    }

    @And("^Number of items  in Shopping Basket page  displayed is \"([^\"]*)\"$")
    public void numberOfItemsInShoppingBasketPageDisplayedIs(String itemQty) {
        String bookQtyDisplayed = editShoppingBasketPage.bookQtyInShoppingBasketPage();
        Assert.assertEquals(itemQty, bookQtyDisplayed);
    }

    @And("^TotalPrice is \"([^\"]*)\"$")
    public void totalpriceIs(String totalPrice) {
        String shoppingBasketValueDispalyed = editShoppingBasketPage.ShoppingBasketValue();
        Assert.assertEquals(totalPrice, shoppingBasketValueDispalyed);
    }
}

