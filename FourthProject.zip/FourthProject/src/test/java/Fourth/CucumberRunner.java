package Fourth;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * Created by theop on 29/10/2017.
 */


@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty", "html:target/html.report", "json:target/json.report"},features = "src/test/resources/features")
public class CucumberRunner {
}
