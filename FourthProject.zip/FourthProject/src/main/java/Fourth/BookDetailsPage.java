package Fourth;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import utils.Utility;

/**
 * Created by theop on 29/10/2017.
 */
public class BookDetailsPage extends BasePage {

    @FindBy(id = "productTitle")
    private WebElement bookTitleDisplayed;
    @FindBy(id = "a-autoid-4-announce")
    private WebElement bookTypeAndPrice;
    @FindBy(id = "add-to-cart-button")
    private WebElement addToBasketButton;

    private String bookType;
    private String bookPrice;

    public String inBookDetailsSection() {
        return Utility.getPageTitle();
    }

    public String bookTitle() {
        return bookTitleDisplayed.getText();
    }

    public String bookPriceSelected() {
        bookOptionSelected();
        return bookPrice;
    }

    public String bookTypeSelected() {
        bookOptionSelected();
        return bookType;
    }

    private void bookOptionSelected() {
        Utility.waitForElementToBeVisbile(bookTypeAndPrice);
        String[] bookTypeAndPriceArray = bookTypeAndPrice.getText().split("\\s+");
        bookType = bookTypeAndPriceArray[0];
        bookPrice = bookTypeAndPriceArray[1];
    }

    public BookDetailsPage addToBasket() {
        addToBasketButton.click();
        return this;

    }
}
