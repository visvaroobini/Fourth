package Fourth;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by theop on 30/10/2017.
 */
public class ShoppingBasketPage extends BasePage {
    @FindBy(id = "huc-v2-order-row-confirm-text")
    private  WebElement addToBasketNotification;
    @FindBy(xpath = "//div[@id='hlb-subcart']/div[1]/span/span[1]")
    private  WebElement numberOfItems;
    @FindBy(id = "hlb-view-cart-announce")
    private WebElement editBasketButton;


    public String addedToBasketNotification() {
        return addToBasketNotification.getText();
    }

    public String numberOfItemsInBasket() {
        String numberOfItemsDisplayed = numberOfItems.getText();
        String[] sArray = numberOfItemsDisplayed.split("\\s+");
        for (String temp : sArray) {
            if (temp.contains("1")) {
                return temp;
            }
        }
        return null;
    }

    public ShoppingBasketPage editBasket() {
        editBasketButton.click();
        return this;
    }
}
