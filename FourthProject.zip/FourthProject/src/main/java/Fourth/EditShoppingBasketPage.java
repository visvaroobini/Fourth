package Fourth;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import utils.Utility;

/**
 * Created by theop on 30/10/2017.
 */
public class EditShoppingBasketPage extends BasePage {

    @FindBy(xpath = "//div[@class='a-row sc-cart-header sc-compact-bottom']")
    private WebElement editShoppingCart;
    @FindBy(xpath = "//ul[@class='a-unordered-list a-nostyle a-vertical a-spacing-mini']/li[1]/span/a")
    private WebElement bookTitle;
    @FindBy(xpath = "//ul[@class='a-unordered-list a-nostyle a-vertical a-spacing-mini']/li[2]/span")
    private WebElement bookType;
    @FindBy(xpath = "//div[@class='a-column a-span2 a-text-left']/p/span")
    private WebElement bookPrice;
    @FindBy(xpath = "//div[@ class='a-column a-span2 a-text-right sc-action-links a-span-last']/div/div/span/select")
    private WebElement bookQty;
    @FindBy(xpath = "//span[@id='sc-subtotal-amount-activecart']")
    private WebElement shoppingBasketvalue;

    public String inEditShoppingCartPage() {
        return editShoppingCart.getText();
    }

    public String bookTitleInshoppingBasketPage() {
        return bookTitle.getText();
    }

    public String bookTypeinShoppingBasketpage() {
        Utility.waitForElementToBeVisbile(bookType);
        return bookType.getText();
    }

    public String bookPriceInShoppingBasketPage() {
        Utility.waitForElementToBeVisbile(bookPrice);
        return bookPrice.getText();
    }

    public String bookQtyInShoppingBasketPage()
    {
        return bookQty.getAttribute("value");
    }

    public String ShoppingBasketValue() {
        return shoppingBasketvalue.getText();
    }
}