package Fourth;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import utils.Utility;

/**
 * Created by theop on 29/10/2017.
 */
public class HomePage extends BasePage {
    @FindBy(linkText = "Amazon.co.uk")
    private WebElement inAmazonPageText;
    @FindBy(id = "searchDropdownBox")
    private WebElement depatments;
    @FindBy(id = "twotabsearchtextbox")
    private WebElement searchField;
    @FindBy(xpath = "//div[@class='nav-search-submit nav-sprite']/input")
    private WebElement submitSearch;

    public String getHomePageTitle() {
        return Utility.getPageTitle();
    }

    public String inAmazonPage() {
        return inAmazonPageText.getText();
    }

    public HomePage gotoBooksSection(String bookSection) {
        Select departmentSelect = new Select(depatments);
        departmentSelect.selectByVisibleText(bookSection);
        return this;
    }

    public HomePage searchsForABook(String bookTitle) {
        searchField.sendKeys(bookTitle);
        submitSearch.click();
        return this;
    }


}
