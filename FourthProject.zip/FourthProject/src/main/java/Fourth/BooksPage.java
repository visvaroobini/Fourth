package Fourth;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import utils.Utility;

import java.util.List;

/**
 * Created by theop on 29/10/2017.
 */

public class BooksPage extends BasePage {

    @FindBy(xpath = "//div[@class='a-fixed-left-grid-col a-col-right']/div/div/a/h2")
    WebElement firstBookResult;
    @FindBy(xpath = "//div[@class='a-fixed-left-grid-col a-col-right']/div[1]/div[1]")
    WebElement bookTitleDisplayed;
    @FindBy(xpath = "    //div[@class='a-fixed-left-grid-col a-col-right']/div[2]/div[1]/div[1]")
    WebElement bookTypeDisplayed;
    @FindBy(xpath = "//div[@class='a-fixed-left-grid-col a-col-right']/div[2]/div[1]/div[2]")
    WebElement bookPriceDisplayed;

    public String bookTitle() {
        WebElement section = bookTitleDisplayed;
        List<WebElement> allBooks = section.findElements(By.tagName("a"));
        return (allBooks.get(0).getText());
    }

    public String bookPrice() {
        Utility.waitForElementToBeVisbile(bookPriceDisplayed);
        WebElement section = bookPriceDisplayed;
        List<WebElement> allPrice = section.findElements(By.tagName("a"));
        return (allPrice.get(0).getText());
    }

    public String bookType() {
        Utility.waitForElementToBeVisbile(bookTypeDisplayed);
        WebElement section = bookTypeDisplayed;
        List<WebElement> allPrice = section.findElements(By.tagName("a"));
        return (allPrice.get(0).getText());
    }

    public BooksPage bookDetails() {
        firstBookResult.click();
        return this;
    }


}
