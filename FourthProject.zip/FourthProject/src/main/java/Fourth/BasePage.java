package Fourth;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import utils.BrowserFactory;

/**
 * Created by theop on 29/10/2017.
 */

    public abstract class BasePage{

        public  static WebDriver driver = BrowserFactory.getDriver(BrowserFactory.driver);

        BasePage() {
            PageFactory.initElements(driver, this);
        }
    }

