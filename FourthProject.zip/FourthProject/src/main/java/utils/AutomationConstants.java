package utils;

/**
 * Created by theop on 29/10/2017.
 */

public class AutomationConstants {
    public static final String URL = "https://www.amazon.co.uk";
    public static final String BROWSER_TYPE = "Chrome";
}
