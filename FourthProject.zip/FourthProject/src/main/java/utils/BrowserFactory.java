package utils;

import io.github.bonigarcia.wdm.ChromeDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static java.util.concurrent.TimeUnit.SECONDS;

/**
 * Created by theop on 29/10/2017.
 */
public class BrowserFactory {
    public static WebDriver driver;

    public static WebDriver startBrowser(String browser, String URL) {
        AutomationConstants.BROWSER_TYPE.equalsIgnoreCase("Chrome");
        ChromeDriverManager.getInstance().setup();
        driver = new ChromeDriver();
        driver.get(AutomationConstants.URL);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, SECONDS);
        return driver;
    }

    public static WebDriver getDriver(WebDriver driver) {
        return driver;
    }

    public static void stopBrowser() {
        driver.close();
    }
}