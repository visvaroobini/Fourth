package utils;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

/**
 * Created by theop on 29/10/2017.
 */
public class Utility extends BrowserFactory {
    static WebDriverWait wait = new WebDriverWait(driver, 60);

    public static String getPageTitle() {
        return driver.getTitle();
    }

    public static WebElement waitForElementToBeVisbile(WebElement locator) {
        return wait.until(ExpectedConditions.visibilityOf(locator));
    }

    public static WebElement fluientWaitforElement(WebElement element, int timoutSec, int pollingSec) {
        FluentWait<WebDriver> fWait = new FluentWait<WebDriver>(driver).withTimeout(timoutSec, TimeUnit.SECONDS)
                .pollingEvery(pollingSec, TimeUnit.SECONDS)
                .ignoring(NoSuchElementException.class, TimeoutException.class);
        fWait.until(ExpectedConditions.visibilityOf(element));
        return element;
    }
}
